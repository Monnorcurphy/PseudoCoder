So, this if the first answers, and as such I want to make sure you
don't screw something up.

I have commented above the code, you should comment your code, it is good
practice. First of all, because you probably write bad code. But when
your employer realizes this, and fires you, then need someone to be able
to tell what your bad code does.

We work with something called amortization. If you don't know what that
means:

https://www.thebalance.com/how-amortization-works-315522
https://www.cs.princeton.edu/~fiebrink/423/AmortizedAnalysisExplained_Fiebrink.pdf
https://www.youtube.com/watch?v=uso8zq5ZtzQ
